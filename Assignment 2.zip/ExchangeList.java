import java.util.*;
public class ExchangeList
{
  private Node first=null;
  private Node last=null;
  int size=0;
  private class Node
  {
     public Exchange data;
     public Node next;
  }
  public boolean isEmpty()
  {
    return(first==null);
  }
  public Exchange item(int i)
  {
    if(i>size)
      throw new IllegalArgumentException();
    Node e=first;
    for(int j=0;j<i-1;j++)
      e=e.next;
    return(e.data);
  }
  public void insert(Exchange e)
  {
   Node n=new Node();
    n.data=e;
    n.next=null;
    if(size==0)
    {
      first=n;
      last=n;
      size++;
    }
    else
    {
    last.next=n;
    last=n;
    size++;
    }
  }
  public String printlist()
  {
    if(first==null)
      throw new NoSuchElementException();
    Node temp=first;
    String s="";
    while(temp!=last)
    {
      s=s+Integer.toString(temp.data.data())+", ";
      temp=temp.next;
    }
    s=s+Integer.toString(temp.data.data());
    //System.out.println(" ");
    return s;
  }
  public boolean IsMember(Exchange e)
  {
    if(first==null)
      return false;
    Node n= first;
    while(n!=null)
    {
      if(n.data.equals(e)==true)
        return true;
      n=n.next;
    }
    return false;
  }
  public int size()
  {
    return(size);
  }
}