import java.util.*;
public class MobilePhoneSet
{
  public Myset s=new Myset();
  public void mobileinsert(MobilePhone m)
  {
    s.Insert(m);
  }
  public void mobiledelete(MobilePhone m)
  {
    s.Delete(m);
  }
  public boolean issetempty()
  {
    return(s.IsEmpty());
  }
  public boolean Ismobilemember(MobilePhone m)
  {
    return(s.IsMember(m));
  }
  public MobilePhoneSet mobileunion(MobilePhoneSet s1)
  {
    MobilePhoneSet s2=new MobilePhoneSet();
    s2.s=s.Union(s1.s);
    return(s2);
  }
  public MobilePhoneSet mobileintersect(MobilePhoneSet s1)
  {
    MobilePhoneSet s2=new MobilePhoneSet();
    s2.s=s.Intersection(s1.s);
    return(s2);
  }
  public MobilePhone mobid(int id)
  {
    Iterator mitr=s.iterator();
    while(mitr.hasNext())
    {
      MobilePhone m = (MobilePhone)mitr.next();
      if(m.number()==id)
        return m;
    }
    return null;
  }
  public String print()
  {
    String s1="";
    if(s.IsEmpty()==true)
     throw new IllegalArgumentException();
    Iterator mitr = s.iterator();
    while(mitr.hasNext()) {
   MobilePhone m = (MobilePhone)mitr.next();
   s1=s1+Integer.toString((m.number()))+", ";
  }
    return(s1.substring(0,s1.length()-2));
  }
}