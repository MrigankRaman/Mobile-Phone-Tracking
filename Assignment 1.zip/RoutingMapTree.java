import java.util.*;
public class RoutingMapTree
{
  private Exchange r;
  private MobilePhoneSet switchedoff=new MobilePhoneSet();
  public RoutingMapTree()//constructor to initialize with 0
  {
    Exchange e=new Exchange(0);
    r=e;
  }
  public RoutingMapTree(Exchange e)//constructor to initialize with e
  {
    r=e;
  }
  private int depth(Exchange e)// calculate depth of a node
  {
    if(e.equals(r))
      return(0);
    else
      return(1+depth(e.parent()));
  }
  public void insert(Exchange a,Exchange b)//insert b as child of a
  {
    if(containsNode(a)==false)
      throw new NoSuchElementException();
    else
    {
       a.makechild(b);
       b.makeparent(a);
    }
  }
  public Boolean containsNode(Exchange a) //Is a in the tree
  {
    
    if(r==null)
      return false;
    if(r.equals(a))
      return true;
    boolean t=false;
    for(int i=0;i<r.numChildren();i++)
    {
    RoutingMapTree b=r.subtree(i);
    t=(b.containsNode(a));
    if(t==true)
      return true;
    }
    return false;
  }
  private Exchange nodeid(int id) // returns exchange with id =id
  {
      if(r.data()==id)
        return(r);
      for(int i=0;i<r.numChildren();i++)
    {
    RoutingMapTree b=r.subtree(i);
    Exchange e1=b.nodeid(id);
    if(e1!=null)
      return(e1);
    }
      return null;
  }
  public Exchange locid(int id) //same as above only throws exception
  {
    Exchange e=nodeid(id);
    if(e==null)
      throw new NoSuchElementException();
    else
      return e;
  }

  public void switchOn(MobilePhone a, Exchange b)// switches on a at b
  {
    if(containsNode(b)==false)
      throw new NoSuchElementException();
    if(b.isleaf()==false)
      throw new IllegalArgumentException();
    if(a.status()==false)
    {
      a.switchOn();
      a.loc=b;
      b.residentSet().mobileinsert(a);
      Exchange e=b.parent();
      while(e.equals(r)==false)
      {
         e.residentSet().mobileinsert(a);
         e=e.parent();
      }
      e.residentSet().mobileinsert(a);
    }
    else if(a.location().equals(b)==false)
    {
      throw new ArithmeticException();
    }
    switchedoff.mobiledelete(a);
  }
  public Exchange root() //returns root
  {
    return(r);
  }
  public Exchange findPhone(MobilePhone m) //finds the phone
  {
    if(switchedoff.Ismobilemember(m)==true)
      throw new ArithmeticException();
    if(r.residentSet().Ismobilemember(m)==false && switchedoff.Ismobilemember(m)==true)
      throw new NoSuchElementException();
    else
      return(m.location());
  }
  private Exchange helper(MobilePhone m) //finds the phone
  {
    if(switchedoff.Ismobilemember(m)==true)
      throw new ArithmeticException();
    if(r.residentSet().Ismobilemember(m)==false && switchedoff.Ismobilemember(m)==true)
      throw new NoSuchElementException();
    else
      return(m.location());
  }
  public void switchOff(MobilePhone a) //switches off a
  {
    if(a.status()==true)
    {
      
      Exchange b=a.location();
      a.switchOff();
      switchedoff.mobileinsert(a);
      b.residentSet().mobiledelete(a);
      Exchange e=b.parent();
      while(e.equals(r)==false)
      {
        e.residentSet().mobiledelete(a);
       // e.residentSet().mobid(a.number()).switchOff();
         e=e.parent();
      }
      r.residentSet().mobiledelete(a);
     // e.residentSet().mobid(a.number()).switchOff();
    }
  }
  public MobilePhone ismobile(int id) //returns mobile with id=id
  {
    MobilePhone m=r.residentSet().mobid(id);
    if(m==null && switchedoff.Ismobilemember(switchedoff.mobid(id))==false)
      throw new NoSuchElementException();
    else if(switchedoff.Ismobilemember(switchedoff.mobid(id))==true)
      throw new ArithmeticException();
      return m;
  }
  public Exchange lowestRouter(Exchange a, Exchange b) //lowest level in which a and b both contained
  {
     if(a==null&&b==null)
      throw new ArithmeticException();
    else if(containsNode(a)==false || a==null)
      throw new NoSuchElementException();
    else if(containsNode(b)==false|| b==null)
      throw new IllegalArgumentException();
    if(a.equals(b)==true)
      return a;
    Exchange e1,e2;
    if(depth(a)>=depth(b))
    {
    e1=a.parent();
     e2=b;
    }
    else
    {
      e1=b.parent();
     e2=a;
    }
    while(e1!=null)
    {
      RoutingMapTree t=new RoutingMapTree(e1) ;
      if(t.containsNode(e2))
        return e1;
      e1=e1.parent();
    }
    return null;
  }
  public ExchangeList routeCall(MobilePhone a, MobilePhone b)// returns list with path of call
  {Exchange e;
    if(switchedoff.Ismobilemember(a)==false&&r.residentSet().Ismobilemember(a)==true&&switchedoff.Ismobilemember(b)==false&&r.residentSet().Ismobilemember(b)==true)
      e= lowestRouter(findPhone(a),findPhone(b));
    else return  null;
    //System.out.println(e.data());
    ExchangeList l=new ExchangeList();
    Exchange temp=findPhone(a);
    while(temp.equals(e)!=true)
    {
      l.insert(temp);
      temp=temp.parent();
    }
    l.insert(temp);
   // System.out.println(temp.data());
    while(temp.equals(findPhone(b))!=true)
    {
      for(int i=0;i<temp.numChildren();i++)
      {
        RoutingMapTree t=temp.subtree(i);
        if(t.containsNode(findPhone(b))==true){
          temp=t.root();
          break;
        }
        }
      l.insert(temp);
     // System.out.println(temp.parent().data());
    }
    return l;
  }
  public void movePhone(MobilePhone a, Exchange b)
  {
    int id=a.number();
    switchOff(a);
    MobilePhone m=new MobilePhone(id);
    switchOn(a,b);
  }
  public String performAction(String actionMessage)
  {
    String s="";
    if(actionMessage.contains("movePhone")==true)
    {
      String s1="";int i;String s2="";
      for( i=10;actionMessage.charAt(i)!=' ';i++)
        s1=s1+actionMessage.substring(i,i+1);
      for(int j=i+1;j<actionMessage.length();j++)
        s2=s2+actionMessage.substring(j,j+1);
      int b=Integer.parseInt(s2);
      int a=Integer.parseInt(s1);
      try
      {
        if(r.residentSet().Ismobilemember(r.residentSet().mobid(a))==false&&switchedoff.Ismobilemember(switchedoff.mobid(a))==false)
          s="Error - No Mobile phone with identifier "+Integer.toString(a)+" is found in the network";
        else if(switchedoff.Ismobilemember(switchedoff.mobid(a))==true)
          movePhone(switchedoff.mobid(a),locid(b));
        else
          movePhone(r.residentSet().mobid(a),locid(b));
      }catch(NoSuchElementException e)
      {
        System.out.print("Error - No Exchange with identifier "+b+" is found in the network");
      }
      catch(IllegalArgumentException e1)
      {
        System.out.print("Error - Exchange"+" "+b+" "+"is not a base station");
      }
    }
    else if(actionMessage.contains("addExchange")==true)
    {
      String s1="";int i;String s2="";
      for( i=12;actionMessage.charAt(i)!=' ';i++)
        s1=s1+actionMessage.substring(i,i+1);
      for(int j=i+1;j<actionMessage.length();j++)
        s2=s2+actionMessage.substring(j,j+1);
      int b=Integer.parseInt(s2);
      int a=Integer.parseInt(s1);
     // System.out.println(a+" "+b);
      Exchange b1=new Exchange(b);
      try{
      insert(locid(a),b1);
      }catch(NoSuchElementException e)
      {
        System.out.println("Error - No Exchange with identifier"+" "+a+" "+"found in the network");
      }
      
    }
    else if(actionMessage.contains("queryNthChild")==true)
    {
      String s1="";int i;String s2="";
      for( i=14;actionMessage.charAt(i)!=' ';i++)
        s1=s1+actionMessage.substring(i,i+1);
      for(int j=i+1;j<actionMessage.length();j++)
        s2=s2+actionMessage.substring(j,j+1);
      int b=Integer.parseInt(s2);
      int a=Integer.parseInt(s1);
      try
      {
        Exchange e=locid(a);
        s="queryNthChild "+Integer.toString(a)+" "+Integer.toString(b)+": "+(Integer.toString(e.child(b).data()));
      }catch(NoSuchElementException e)
      {
        System.out.print("queryNthChild "+a+" "+b+": "+"Error - No Exchange with identifier"+" "+a+" "+"found in the network");
      }
      catch( IllegalArgumentException e1)
              { System.out.print("queryNthChild "+a+" "+b+": "+"Error - Exchange"+" "+a+" "+"does not have"+" "+b+"th child");
      }
    }
    else if(actionMessage.contains("switchOnMobile")==true)
    {
      String s1="";int i;String s2="";
      for( i=15;actionMessage.charAt(i)!=' ';i++)
        s1=s1+actionMessage.substring(i,i+1);
      for(int j=i+1;j<actionMessage.length();j++)
        s2=s2+actionMessage.substring(j,j+1);
      int b=Integer.parseInt(s2);
      int a=Integer.parseInt(s1);
      try
      {
        MobilePhone m;
        //if(switchedoff.Ismobilemember(switchedoff.mobid(a))==false)
        if(r.residentSet().Ismobilemember(r.residentSet().mobid(a))==false)
          m=new MobilePhone(a);
        //else{
          //m=switchedoff.mobid(a);
          //System.out.println(m.number()+"b");
           else
             m=ismobile(a);
        //}
        switchOn(m,locid(b));
      }catch(NoSuchElementException e)
      {
        System.out.println("Error - No Exchange with identifier"+" "+b+" "+"found in the network");
      }
      catch(IllegalArgumentException e1)
      {
        System.out.println("Error - Exchange"+" "+b+" "+"is not a base station");
      }
      catch(ArithmeticException e2)
      {
        System.out.println("Error - Mobile phone"+" "+a+" "+"is already switched on elsewhere"+" "+"at Exchange"+" "+r.residentSet().mobid(a).location().data());
      }
    }
    else if(actionMessage.contains("findPhone")==true)
    {
       String s1="";
      for(int j=10;j<actionMessage.length();j++)
        s1=s1+actionMessage.substring(j,j+1);
      int a=Integer.parseInt(s1);
      try{
      s="queryFindPhone "+Integer.toString(a)+": "+(Integer.toString(findPhone(ismobile(a)).data()));
      }
        catch(NoSuchElementException e)
      {
        s=("queryFindPhone "+Integer.toString(a)+": "+"Error - No mobile phone with identifier"+" "+Integer.toString(a)+" "+"found in the network");
      }
    catch(ArithmeticException e)
      {
        System.out.print("queryFindPhone "+a+": "+"Error - Mobile phone with identifier"+" "+a+" "+"is currently switched off");
      }
  }
    else if(actionMessage.contains("switchOffMobile")==true)
    {
      String s1="";
      for(int j=16;j<actionMessage.length();j++)
        s1=s1+actionMessage.substring(j,j+1);
      int a=Integer.parseInt(s1);
      try
      {
        MobilePhone m=ismobile(a);
        switchOff(m);
      }catch(NoSuchElementException e)
      {
       System.out.println("Error - Mobile phone with identifier"+" "+a+" "+"is currently switched off");
      }
    }
    else if(actionMessage.contains("lowestRouter")==true)
    {
       String s1="";int i;String s2="";
      for( i=13;actionMessage.charAt(i)!=' ';i++)
        s1=s1+actionMessage.substring(i,i+1);
      for(int j=i+1;j<actionMessage.length();j++)
        s2=s2+actionMessage.substring(j,j+1);
      int b=Integer.parseInt(s2);
      int a=Integer.parseInt(s1);
      s=s+"queryLowestRouter "+Integer.toString(a)+" "+Integer.toString(b)+": ";
      try
      {
        s=s+(Integer.toString(lowestRouter(nodeid(a),nodeid(b)).data()));
      }catch(NoSuchElementException e)
      {
        System.out.print("Error - No Exchange with identifier"+" "+a+" "+"found in the network");
      }
      catch(IllegalArgumentException e1)
      {
        System.out.print("Error - No Exchange with identifier"+" "+b+" "+"found in the network");
      }
      catch(ArithmeticException e2)
      {
        System.out.print("Error - Both Exchanges are not available");
      }
    }
    else if(actionMessage.contains("findCallPath")==true)
    {
      String s1="";int i;String s2="";
      for( i=13;actionMessage.charAt(i)!=' ';i++)
        s1=s1+actionMessage.substring(i,i+1);
      for(int j=i+1;j<actionMessage.length();j++)
        s2=s2+actionMessage.substring(j,j+1);
      int b=Integer.parseInt(s2);
      int a=Integer.parseInt(s1);
      s=s+"queryFindCallPath "+Integer.toString(a)+" "+Integer.toString(b)+": ";
      if(switchedoff.Ismobilemember(switchedoff.mobid(a))==true&&switchedoff.Ismobilemember(switchedoff.mobid(b))==true)
      {
        s=s+("Error - Both Mobiles are switched off");
        //return("");
      }
      else if(switchedoff.Ismobilemember(switchedoff.mobid(a))==true)
      {
        s=s+("Error - Mobile phone with identifier "+Integer.toString(a)+" is currently switched off");
        //return("");
      }
      else if(switchedoff.Ismobilemember(switchedoff.mobid(b))==true)
      {
        s=s+("Error - Mobile phone with identifier "+Integer.toString(b)+" is currently switched off");
        //return("");
      }
      else if(r.residentSet().Ismobilemember(r.residentSet().mobid(a))==false&&r.residentSet().Ismobilemember(r.residentSet().mobid(b))==false)
      {
        s=s+("Error - Both Mobiles are not available");
        //return("");
      }
      else if(r.residentSet().Ismobilemember(r.residentSet().mobid(a))==false)
      {
       s=s+("Error - No mobile phone with identifier "+Integer.toString(a)+" found in the network");
       //return("");
      }
       else if(r.residentSet().Ismobilemember(r.residentSet().mobid(b))==false)
      {
        s=s+("Error - No mobile phone with identifier "+Integer.toString(b)+" found in the network");
      }
       else
       {
         ExchangeList l=routeCall(r.residentSet().mobid(a),r.residentSet().mobid(b));
         s=s+(l.printlist());
       }
    }
    else if(actionMessage.contains("queryMobilePhoneSet")==true)
    {
      String s1="";
      for(int j=20;j<actionMessage.length();j++)
        s1=s1+actionMessage.substring(j,j+1);
      int a=Integer.parseInt(s1);
      try
      {
        Exchange e=locid(a);
        s="queryMobilePhoneSet "+Integer.toString(a)+": "+(e.residentSet().print());
      }catch(NoSuchElementException e)
      {
        System.out.print("queryMobilePhoneSet "+a+": "+"Error - No Exchange with identifier"+" "+a+" "+"found in the network");
      }
      catch(IllegalArgumentException e1)
      {
        System.out.print("queryMobilePhoneSet "+a+": "+"Error - No Mobiles Registered with Exchange"+" "+a);
      }
    }
    return(s);
  }
  public static void main(String[] args)
  {
    RoutingMapTree t=new RoutingMapTree();
    /*MobilePhone a1=new MobilePhone(1);
    MobilePhone a2=new MobilePhone(2);
    MobilePhone a3=new MobilePhone(3);
    MobilePhone a4=new MobilePhone(4); 
    MobilePhone a5=new MobilePhone(5);
    MobilePhone a6=new MobilePhone(6);
    MobilePhone a7=new MobilePhone(7);
    MobilePhone a8=new MobilePhone(8);
    MobilePhone a9=new MobilePhone(9);
    MobilePhone a10=new MobilePhone(10);
    MobilePhone a11=new MobilePhone(11);
    MobilePhone a12=new MobilePhone(12);
    MobilePhone a13=new MobilePhone(13);
    MobilePhone a14=new MobilePhone(14);
    MobilePhone a15=new MobilePhone(15);
    MobilePhone a16=new MobilePhone(16);
    MobilePhone a17=new MobilePhone(17);
    MobilePhone a18=new MobilePhone(18);
    MobilePhone a19=new MobilePhone(19);
    Exchange e1= new Exchange(1);
    Exchange e2= new Exchange(2);
    Exchange e3= new Exchange(3);
    Exchange e4= new Exchange(4);
    Exchange e5= new Exchange(5);
    Exchange e6= new Exchange(6);
    Exchange e7= new Exchange(7);
    Exchange e8= new Exchange(8);
   t.insert(t.root(),e1);
   t.insert(t.root(),e2);
   t.insert(t.root(),e3);
   t.insert(e1,e4);
   t.insert(e1,e5);
   t.insert(e1,e6);
   t.insert(e3,e7);
   t.insert(e7,e8);
    t.switchOn(a1,e4);
    t.switchOn(a2,e7);
    t.switchOn(a3,e5);
    t.switchOn(a4,e7);
    t.switchOn(a5,e6);
    t.switchOn(a6,e6);
    t.switchOn(a7,e6);
    t.switchOn(a8,e7);
    t.switchOn(a9,e5);
    t.switchOn(a10,e5);
    t.switchOn(a11,e4);
    t.switchOn(a12,e5);
    t.switchOn(a13,e4);
    t.switchOn(a14,e6);
    t.switchOn(a15,e6);
    t.switchOn(a16,e4);
    t.switchOn(a17,e7);
    t.switchOn(a18,e6);
    t.switchOn(a19,e5); 
    t.switchOff(a14);
    MobilePhone m=new MobilePhone(20);
    t.switchOn(m,t.locid(5));
    t.root().residentSet().print();*/
   //System.out.println(t.root().residentSet().mobid(14).status());
   // System.out.println(t.root().residentSet().Ismobilemember(t.root().residentSet().mobid(14)));
    //System.out.println(t.lowestRouter(e8,e5).data());
    //System.out.println(t.locid(0).residentSet().Ismobilemember(mobid(20)));
  System.out.print(t.performAction("addExchange 0 1"));
System.out.print(t.performAction("addExchange 0 2"));
System.out.print(t.performAction("addExchange 0 3"));
//System.out.println(t.lowestRouter(t.locid(2),t.locid(3)).data());
System.out.println(t.performAction("queryNthChild 0 0"));
System.out.println(t.performAction("queryNthChild 0 2"));
System.out.print(t.performAction("addExchange 1 4"));
System.out.print(t.performAction("switchOnMobile 989 4"));
System.out.print(t.performAction("switchOnMobile 876 4"));
System.out.println(t.performAction("queryMobilePhoneSet 0"));
System.out.println(t.performAction("queryMobilePhoneSet 100"));
System.out.print(t.performAction("addExchange 1 5"));
System.out.print(t.performAction("addExchange 2 6"));
System.out.print(t.performAction("addExchange 1 7"));
System.out.print(t.performAction("switchOnMobile 700 5"));
System.out.println(t.performAction("queryFindCallPath 700 989"));
System.out.print(t.performAction("switchOffMobile 989"));
System.out.print(t.performAction("switchOffMobile 700"));
System.out.println(t.performAction("queryFindCallPath 700 989"));
System.out.print(t.performAction("movePhone 700 6"));
System.out.print(t.performAction("movePhone 989 7"));
System.out.println(t.performAction("queryFindCallPath 700 989"));
System.out.println(t.performAction("queryLowestRouter 1 2"));
/*t.performAction("addExchange 1 5");
//System.out.println(t.lowestRouter(t.locid(4),t.locid(5)).data());
t.performAction("addExchange 2 6");
t.performAction("addExchange 2 7");
t.performAction("addExchange 2 8");
t.performAction("addExchange 3 9");
t.performAction("addExchange 6 10");
t.performAction("addExchange 3 9");
//System.out.println(t.lowestRouter(t.locid(7),t.locid(10)).data()+"a");
t.performAction("queryNthChild 2 0");
t.performAction("queryNthChild 3 0");
t.performAction("switchOnMobile 989 4");
t.performAction("switchOnMobile 876 4");
t.performAction("queryMobilePhoneSet 4");
t.performAction("queryMobilePhoneSet 1");
t.performAction("switchOnMobile 656 5");
t.performAction("switchOnMobile 54 5");
t.performAction("queryNthChild 3 10");
t.performAction("queryMobilePhoneSet 1");
t.performAction("switchOffMobile 656");
t.performAction("queryMobilePhoneSet 1");
t.performAction("switchOnMobile 213 6");
t.performAction("switchOnMobile 568 7");
t.performAction("switchOnMobile 897 8");
t.performAction("switchOnMobile 295 8");
t.performAction("switchOnMobile 346 9");
//t.performAction("queryMobilePhoneSet 0");
//t.performAction("switchOffMobile 346");
//t.performAction("switchOffMobile 900");
//t.performAction("switchOnMobile 656 5");
t.performAction("switchOnMobile 346 7");
t.performAction("switchOffMobile 80");
t.performAction("queryMobilePhoneSet 0");
t.performAction("queryMobilePhoneSet 7");
t.performAction("queryFindPhone 656");

//t.switchedoff.print();
//System.out.println(t.root().residentSet().Ismobilemember(t.root().residentSet().mobid(651)));
ExchangeList l=t.routeCall(t.root().residentSet().mobid(568),t.root().residentSet().mobid(897));
l.printlist();*/
  }
}