public class MobilePhone
{
  private int id;
  private boolean stat=false;
  public Exchange loc;
  public MobilePhone(int number)
  {
    id=number;
  }
  public int number()
  {
    return(id);
  }
  public boolean status()
  {
    return(stat);
  }
  public void switchOn()
  {
    stat=true;
  }
  public void switchOff()
  {
    stat=false;
  }
  public Exchange location()
  {
    if(stat==true)
      return(loc);
    else
      throw new IllegalArgumentException();
  }
   public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        MobilePhone that = (MobilePhone) y;
        int n=this.number();
        if(n!=that.number())
          return(false);
        else
          return true;
    }
}